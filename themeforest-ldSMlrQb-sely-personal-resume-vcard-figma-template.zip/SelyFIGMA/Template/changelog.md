# Sely - Personal Resume vCard Figma Template #

## Changelog list: ##

### 1.1.0 ###
Update: Text styles and components

### 1.0.0 ###
- Initial release
